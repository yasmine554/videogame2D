/**
* @file background.c
* @brief  fichier .c de background
* @author NOT YET Yasmine Sliti 1A3
* @version 1.0
* @date June 2020

*/

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "background.h"

/**@brief Initialisation de la fonction background
   @param b struct background
   @param url char
   @return void
*/

void initBckg (background * b, char url[]){
b->img = IMG_Load (url);
b->bckg.x = 0;
b->bckg.y = 0;
b->bckg.w = b->img->w;
b->bckg.h = b->img->h;
}

/**@brief affichage du background 
   @param screen SDL_Surface
   @param b struct background
   @return void
*/
void showBckg (SDL_Surface * screen, background b){
SDL_BlitSurface (b.img, &(b.bckg), screen, NULL);
}

/**@brief scrooling a gauche
   @param struct background
   @return void
*/ 
void scrollToLeft (background * b){
if (b->bckg.x != 0)
b->bckg.x--;
}

/**@brief scrolling a droite
   @param b struct background
   @return void
*/
void scrollToRight (background * b){
if (b->bckg.w - b->bckg.x != CAMERA_W)
b->bckg.x++;
}

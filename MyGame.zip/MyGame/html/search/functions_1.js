var searchData=
[
  ['scrolltoleft',['scrollToLeft',['../background_8c.html#ae325b42fa1f2e50ce1eb289d21b2a372',1,'background.c']]],
  ['scrolltoright',['scrollToRight',['../background_8c.html#a6ee97702bdd9933893a41c34fa2c2aca',1,'background.c']]],
  ['showbckg',['showBckg',['../background_8c.html#a74cde2d2df1f88fdb2e0ba62193f124c',1,'background.c']]]
];

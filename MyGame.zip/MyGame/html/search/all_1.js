var searchData=
[
  ['initbckg',['initBckg',['../background_8c.html#a78e1c93646d00d2c16bb3533cf18cf34',1,'background.c']]]
];
